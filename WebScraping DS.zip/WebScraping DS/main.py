print('FUCK YOU!!!!!!!........')
"""
the basic structure of the program or of my style is, i give command in upper the code.
and i try to make more readable. thankyou for your attentions.
"""
# the below library is used to give https request
import requests
# the below library for analysis the html file by tags. it easy to filter the content
from bs4 import BeautifulSoup as bs
# for handle the data
import pandas as pd

"""
!!!dependency of this project!!!
openpyxl package is used to handle the excel file. 
"""

# import the data from the this project
input_data = pd.read_excel('data/input.xlsx')

'''
Global Variable..........
'''
length_of_input_url = len(input_data)

"""
Functions
"""

#this define is used to save txt file in machine
def save_text_to_file(text_list, file_path):
    try:
        with open(file_path, 'w', encoding='utf-8') as file:
            for text in text_list:
                file.write(text + '\n')  # Write each text followed by a newline character
        print("Text data saved successfully.")
    except Exception as e:
        print("Error occurred while saving text data:", e)

#textual data extraction function
def extract_data_from_web():
    try:
        html = requests.get(url)
        soup = bs(html.text, 'html.parser')
        heading = soup.find('h1').text.strip()
        text_list.append(heading)
        #print(heading)
        para = soup.find('div', class_='td-post-content tagdiv-type').find_all('p')
        for p in para:
            text_list.append(p.text)
            #print(p.text)
        para1 = soup.find('div', class_='td-post-content tagdiv-type').find_all('ol')
        for p in para1:
            text_list.append(p.text)
            #print(p.text)
        print(text_list)
        save_text_to_file(text_list,file_path)
    except Exception as err:
        print('error')
        print(err)

# this for loop iterate the excel file and save txt file in machine
for index, row in input_data.iterrows():
    url_id= row['URL_ID']
    url= row['URL']
    text_list = []
    file_path = f"output/{url_id}.txt"
    extract_data_from_web()



